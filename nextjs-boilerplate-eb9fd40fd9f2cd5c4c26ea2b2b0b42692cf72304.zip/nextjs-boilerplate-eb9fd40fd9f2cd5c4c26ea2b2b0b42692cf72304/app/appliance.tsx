import React from "react";
import { FiSun, FiCheckCircle } from "react-icons/fi"; 
import '../app/globals.css'; 

interface AppliancesProps {
  handleToggle: (key: string) => void;
  actuationData: Record<string, number>;
}

const Appliances: React.FC<AppliancesProps> = ({ handleToggle, actuationData }) => {
  return (
    <div className="flex flex-wrap gap-5">
      {Object.entries(actuationData).map(([key, value]) => (
        <div 
          key={key}
          className="p-5 bg-yellow-200 relative border border-gray-300 rounded-lg h-45 w-48 text-center shadow-lg"
        >
          {/* Light and Connected Icons */}
          <div className="absolute top-2 left-2 flex gap-1 items-center">
            <FiSun className="text-yellow-950" />
          </div>
          <div className="absolute top-2 right-2 flex gap-1 items-center">
            <FiCheckCircle
              className="text-green-500"
            />
          </div>

          <div className="h-2"></div>
          <h3 className="font-semibold text-lg">{key}</h3>

          {/* Toggle Switch */}
          <label className="inline-flex items-center mt-4 cursor-pointer">
          <span className={`mr-2 text-sm ${value === 1 ? "text-green-500" : "text-red-500"}`}>
  {value === 1 ? "On" : "Off"}
</span>
            <input
              type="checkbox"
              className="sr-only peer"
              checked={value === 1}
              onChange={() => handleToggle(key)}
              id={`toggle-${key}`}
            />
            <div className="h-12"></div>
            <div className="relative w-11 h-6 bg-gray-200 rounded-full peer   dark:bg-red-700 peer-checked:bg-green-500">
              <span
                className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white border-2 border-gray-300 rounded-full transition-transform duration-300 ${
                  value === 1 ? "translate-x-full" : ""
                }`}
              ></span>
            </div>
          </label>
        </div>
      ))}
    </div>
  );
};

export default Appliances;
