"use client"; 
import './globals.css';
import { getDatabase, ref, onValue, update } from "firebase/database";
import { useEffect, useState } from "react";
import { app } from "./firebase/config";
import Appliances from "./appliance";

export default function Home() {
  const [actuationData, setActuationData] = useState<Record<string, number>>({});

  useEffect(() => {
    const db = getDatabase(app);
    const actuationRef = ref(db, "lab/actuation");

    // Fetch data and set state
    onValue(actuationRef, (snapshot) => {
      if (snapshot.exists()) {
        setActuationData(snapshot.val() as Record<string, number>);
      } else {
        console.log("No data available");
      }
    });
  }, []);

  // Handle toggle button click
  const handleToggle = (key: string) => {
    const db = getDatabase(app);
    const actuationRef = ref(db, `lab/actuation`);

    // Prepare the updated value
    const updatedValue = { [key]: actuationData[key] === 1 ? 0 : 1 };

    // Update the value in Firebase
    update(actuationRef, updatedValue)
      .then(() => {
        console.log(`Updated ${key} to ${updatedValue[key]}`);
      })
      .catch(console.error);
  };

  return (
    <div className='p-20'>
      <h1 className="text-3xl font-bold underline p-10">Speech Automation</h1>
      <Appliances handleToggle={handleToggle} actuationData={actuationData} />
    </div>
  );
}
